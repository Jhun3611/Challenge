<?php
$servername = "localhost";
$username = "Jhun007";
$password = "007";
$dbname = "challenge_bd";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    $date = date("Y-m-d H:i:s"); 

    
    $sql = "INSERT INTO contatos (Nome, Email, Mensagem, data_envio) VALUES ('$name', '$email', '$message', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "Obrigado, $name! Sua mensagem foi enviada com sucesso.";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>