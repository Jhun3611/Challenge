<?php

$host = 'localhost';
$dbname = 'contato'; 
$user = 'root'; 
$pass = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar com o banco de dados: " . $e->getMessage());
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $mensagem = $_POST['message'] ?? '';


    if (!empty($nome) && !empty($email) && !empty($mensagem)) {
        try {
            $sql = "INSERT INTO mensagens (nome, email, mensagem) VALUES (:nome, :email, :mensagem)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nome' => $nome,
                ':email' => $email,
                ':mensagem' => $mensagem,
            ]);
            echo "Mensagem enviada com sucesso!";
        } catch (PDOException $e) {
            echo "Erro ao salvar a mensagem: " . $e->getMessage();
        }
    } else {
        echo "Por favor, preencha todos os campos.";
    }
}
?>
